*PADS-LIBRARY-PART-TYPES-V9*

RC1206FR-074K7L RESC3116X65N I RES 7 1 0 0 0
TIMESTAMP 2025.12.04.18.05.00
"TME Electronic Components Part Number" 
"TME Electronic Components Price/Stock" 
"Manufacturer_Name" YAGEO
"Manufacturer_Part_Number" RC1206FR-074K7L
"Description" Yageo 4.7k, 1206 (3216M) Thick Film SMD Resistor +/-1% 0.5 W, 0.25 W - RC1206FR-074K7L
"Datasheet Link" https://componentsearchengine.com/Datasheets/2/RC1206FR-074K7L.pdf
"Geometry.Height" 0.65mm
GATE 1 2 0
RC1206FR-074K7L
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
16314850/1838588/2.50/2/4/Resistor
